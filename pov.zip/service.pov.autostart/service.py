import xbmc

monitor = xbmc.Monitor()
# Allow Kodi's home screen, other startup services, and addon discovery to settle.
if not monitor.waitForAbort(6):
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.pov/",return)')
